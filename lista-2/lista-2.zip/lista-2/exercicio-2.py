valor = float(input("Digite um valor "))

if (valor>= 0):
    print("O valor é positivo")
elif (valor<0):
    print("O valor é negativo")