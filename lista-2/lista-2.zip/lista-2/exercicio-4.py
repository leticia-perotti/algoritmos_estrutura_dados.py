valor1 = float(input("Digite o valor 1: "))
valor2 = float(input("Digite o valor 2: "))

if (valor1 > valor2):
    print("O valor %.2f é maior" % valor1)
elif (valor1 < valor2):
    print("O valor %.2f é maior" % valor2)
else:
    print("Erro!")