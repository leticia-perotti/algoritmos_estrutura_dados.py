valor = int(input("Digite um valor"))

if (valor == 1):
    print("O valor correspondente em algaritmos romanos é I")
elif (valor == 5):
    print("O valor correspondente em algaritmos romanos é V")
elif (valor == 10):
    print("O valor correspondente em algaritmos romanos é X")
elif (valor == 50):
    print("O valor correspondente em algaritmos romanos é L")
elif (valor == 100) :
    print("O valor correspondente em algaritmos romanos é C")
elif (valor == 500):
    print("O valor correspondente em algaritmos romanos é D")
elif (valor == 1000):
    print("O valor correspondente em algaritmos romanos é M")
else: 
    print("Erro!")

"""

while i<valor:
    if((valor /1000) >= 1):
        while valor > 1000:
            numero = numero -1000
            romano = temp.append('M')
    
    if((valor /500) >= 1):
        while valor > 500:
            numero = numero -500
            romano = temp.append('D')
    
            
    if((valor /100) >= 1):
        while valor > 100:
            numero = numero -100
            romano = temp.append('C')

    if((valor /50) >= 1):
        while valor > 1000:
            numero = numero -1000
            romano = temp.append('L')

    if((valor /10) >= 1):
        while valor > 10:
            numero = numero -10
            romano = temp.append('X')

    if((valor /5) >= 1):
        while valor > 5:
            numero = numero -5
            romano = temp.append('V')

    if((valor / 1) >= 1):
        while valor > 1:
            numero = numero -1
            romano = temp.append('I')
    i = i +1 



temp.append
"""