def gerarLista():

    listaRandom1000 = []
    listaRandom10000 = []
    listaRandom100000 = []
    listaRandom1000000 = []
    listaRandom10000000 = []

    for i in range(1000):
        listaRandom1000.append(i)

    for i in range(10000):
        listaRandom10000.append(i)

    for i in range(100000):
        listaRandom100000.append(i)

    for i in range(1000000):
        listaRandom1000000.append(i)

    for i in range(10000000):
        listaRandom10000000.append(i)

    return listaRandom1000,listaRandom10000,listaRandom100000,listaRandom1000000,listaRandom10000000

