﻿aleatorias = [
# etc
'folha', 'pedra', 'tempo', 'mesa', 'noiva', 'casamento',
'zumbi', 'impressora', 'python', 'médico', 'recipiente', 
'haste', 'dardo', 'locomotiva', 'navio', 'ouro', 'quadro',
'computador', 'geografia', 'barco', 'dinossauro', 'violino',
'bateria', 'celular', 'igreja', 'biblioteca', 'tabuleiro',
'teclado', 'programação', 'disquete', 'dardo', 'gancho',
'vasilha', 'prateleira', 'camisa', 'terno', 'meia', 'lareira',
'geladeira', 'boneca', 'escova', 'cabelo', 'torneira', 'gaiola',
'televisão', 'papelão', 'garrafa', 'medicamento', 'ônibus', 
# Animais
'peixe', 'lagosta', 'ornitorrinco', 'arara', 'jabuti',
'lagosta', 'guepardo', 'cachorro', 'arraia', 'canguru',
'pomba', 'raposa', 'camelo', 'vaca', 'codorna', 'esquilo',
'cobra', 'elefante', 'falcão', 'ganso', 'girafa', 'hiena',
'cavalo', 'morcego', 'lontra', 'jaguar', 'javali', 'gato',
'jumento', 'orangotango', 'ovelha', 'porco', 'rinoceronte',
'suricate', 'urso', 'urubu', 'galina',

# Alimento
'abacaxi', 'laranja', 'gelatina', 'amendoim', 'caqui', 'amora',
'abacate', 'tangerina', 'cereja', 'framboesa', 'banana', 'mimosa',
'goiaba', 'kiwi', 'pipoca', 'arroz', 'carne', 'cebola',
'batata', 'comida', 'peixe', 'risoto',

# País
'Brasil', 'Noruega', 'Inglaterra', 'Argentina', 'Italia', 'Palestina', 'Cuba',
'Portugal', 'Peru', 'China',

#linguagens de programação
'delphi', 'php', 'java', 'javascript', 'react', 'django', 'springboot', 'laravel', 'postgresql', 'mysql', 'database', 'arduino', 'kivy'
]