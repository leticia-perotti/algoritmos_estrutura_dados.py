def areaCircunferencia(raio):
    area = 3.14 * (raio * raio)
    return area

def perimetroCircunferencia(raio):
    perimetro = 2 * 3.14 * raio
    return perimetro

def areaRetangulo(base, altura):
    area = base * altura;
    return area

def perimetroRetangulo(base, altura):
    perimetro = (base * 2) + (altura * 2)
    return perimetro

def areaTrianguloEquilatero(lado):
    area = (lado * lado) * 1.73
    area = area/4
    return area

def perimetroTrianguloEquilatero(lado):
    perimetro = (lado * 3)
    return perimetro