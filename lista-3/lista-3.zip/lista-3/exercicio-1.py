i = 57

while i<=252:
    print(i)
    i = i + 1