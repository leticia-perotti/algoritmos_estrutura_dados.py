valor = int(input("Digite um valor"))

for i in range(0, valor + 1, 1):
    print(i)