i = 0
soma = 0

while i<10:
    valor = float(input("Digite um valor"))

    soma = soma + valor
    i = i + 1

media = soma / 10
print("A média é %.2f" % media)

