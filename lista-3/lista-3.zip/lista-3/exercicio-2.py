uniuv = "UNIUV"

i = 0

while i<5:
    print(uniuv)
    i = i + 1