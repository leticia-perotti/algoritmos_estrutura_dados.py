
for i in range(200,0, -1):
    print(i)