soma = 0

for i in range(0, 6, 1):
    valor = int(input('Digite um valor: '))

    soma = soma + valor

print("A soma é %d" % soma)