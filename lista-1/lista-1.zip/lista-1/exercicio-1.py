
raio = float(input("Digite o valor do raio"))
pi = 3.14
area = (raio * raio) * pi;
print("A área do círculo é de ", area)