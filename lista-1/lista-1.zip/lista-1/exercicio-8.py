tempo = float(input("Tempo decorrido "))

metros = tempo * 340
km = metros / 1000

print("A distancia é de %.2f" % km)