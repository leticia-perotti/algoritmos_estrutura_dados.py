nome = input("Olá! Qual o seu nome? ")
idade = input("E a idade? ")
altura = input("E a altura? ")
peso = input("E o peso? ")
nacionalidade = input("E a nacionalidade? ")

print ("Olá %s, sua idade é %s, a altura de %s, seu peso é %s, e a nacionalidade %s" % (nome, idade, altura,peso, nacionalidade))