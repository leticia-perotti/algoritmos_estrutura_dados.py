valorReais = float(input("Digite o valor em reias"))
valorCotacao = float(input("Valor da cotação"))

valorDolar = valorReais / valorCotacao;

print("O valor em dolar é $ %.2f" % valorDolar)